from pydantic import BaseModel
from typing import List
from enum import Enum

class OrderStatus(str, Enum):
    pending = "pending"
    preparing = "preparing"
    completed = "completed"

class OrderItem(BaseModel):
    item_name: str
    quantity: int
    price: float

class OrderCreate(BaseModel):
    customer_name: str
    items: List[OrderItem]

class Order(OrderCreate):
    id: int
    status: OrderStatus
