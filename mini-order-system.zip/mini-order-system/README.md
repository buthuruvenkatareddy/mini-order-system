# Mini Order System – FastAPI

## Description
A simple REST API to manage food delivery orders using Python and FastAPI with in-memory storage.

## Features
- Create new orders
- View all orders
- Fetch order by ID
- Update order status
- View total order summary

## Setup Instructions
1. Clone the repository
2. Install dependencies:
```bash
pip install -r requirements.txt
