from fastapi import FastAPI, HTTPException, Query
from typing import List
from schemas import Order, OrderCreate, OrderStatus
from models import orders

app = FastAPI()
order_id_counter = 1

@app.post("/orders", response_model=Order)
def create_order(order: OrderCreate):
    global order_id_counter
    new_order = Order(
        id=order_id_counter,
        customer_name=order.customer_name,
        items=order.items,
        status=OrderStatus.pending
    )
    orders.append(new_order)
    order_id_counter += 1
    return new_order

@app.get("/orders", response_model=List[Order])
def get_all_orders():
    return orders

@app.get("/orders/{order_id}", response_model=Order)
def get_order(order_id: int):
    for order in orders:
        if order.id == order_id:
            return order
    raise HTTPException(status_code=404, detail="Order not found")

@app.put("/orders/{order_id}/status", response_model=Order)
def update_order_status(order_id: int, status: OrderStatus = Query(...)):
    for order in orders:
        if order.id == order_id:
            order.status = status
            return order
    raise HTTPException(status_code=404, detail="Order not found")

@app.get("/orders/summary")
def get_summary():
    total_orders = len(orders)
    total_value = sum(
        sum(item.price * item.quantity for item in order.items)
        for order in orders
    )
    return {
        "total_orders": total_orders,
        "total_value": round(total_value, 2)
    }
