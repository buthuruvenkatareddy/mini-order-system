from typing import List
from schemas import Order

# In-memory storage
orders: List[Order] = []

# Global order ID counter
order_id_counter = 1
